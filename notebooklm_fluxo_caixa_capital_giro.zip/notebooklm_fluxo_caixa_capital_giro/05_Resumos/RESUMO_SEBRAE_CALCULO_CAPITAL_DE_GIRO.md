# Resumo — SEBRAE — Conheça o capital de giro e saiba como fazer o cálculo

## 1) Conceito (em 3–6 bullets)
- 

## 2) Por que importa (impacto no comércio)
- 

## 3) Erros comuns
- 

## 4) Ações práticas
- 

## 5) Citações / referências
- (Cole trechos com página/section)
