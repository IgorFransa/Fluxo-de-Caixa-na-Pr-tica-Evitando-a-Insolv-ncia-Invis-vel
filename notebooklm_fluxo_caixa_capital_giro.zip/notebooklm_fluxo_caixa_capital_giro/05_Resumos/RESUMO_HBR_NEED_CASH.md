# Resumo — HBR — Need Cash? Look Inside Your Company (opcional)

## 1) Conceito (em 3–6 bullets)
- 

## 2) Por que importa (impacto no comércio)
- 

## 3) Erros comuns
- 

## 4) Ações práticas
- 

## 5) Citações / referências
- (Cole trechos com página/section)
