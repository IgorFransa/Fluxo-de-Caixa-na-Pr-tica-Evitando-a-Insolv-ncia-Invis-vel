# Glossário (definições curtas + exemplo)

> Preencha com: **definição (1–2 linhas)** + **exemplo (1 linha)** + **onde aparece na fonte**.

## EBITDA
- Definição:
- Exemplo:
- Fonte/onde:

## Ciclo Operacional
- Definição:
- Exemplo:
- Fonte/onde:

## Ciclo Financeiro
- Definição:
- Exemplo:
- Fonte/onde:

## Burn Rate
- Definição:
- Exemplo:
- Fonte/onde:

## NCG (Necessidade de Capital de Giro)
- Definição:
- Exemplo:
- Fonte/onde:

## PMR / PMP / PME
- Definição:
- Exemplo:
- Fonte/onde:
