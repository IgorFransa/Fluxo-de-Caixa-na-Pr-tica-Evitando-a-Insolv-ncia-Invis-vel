# MINIGUIA — Fluxo de Caixa e Capital de Giro (Comércio)

## 1) Resumo executivo (1 página)
- **Problema**: empresa pode ter lucro e ainda assim quebrar por falta de caixa.
- **Causa típica no comércio**: prazos (recebe depois do que paga) + estoque alto.
- **Ferramentas**: fluxo de caixa + ciclos (CO/CF) + capital de giro/NCG.

## 2) Modelo mental: lucro ≠ caixa
- Lucro é apuração contábil do período.
- Caixa é liquidez imediata (dinheiro disponível) e depende de *timing* de recebimentos e pagamentos.

## 3) O básico do Fluxo de Caixa
- Monte por **datas** (não só por competência).
- Separe entradas/saídas por categoria.
- Use para prever falta/sobra antes de acontecer.

## 4) Capital de Giro no comércio (o que mais pesa)
- Estoque e contas a receber tendem a “travar” caixa.
- Aumentar PMP (sem perder condição) e reduzir PMR/PME costuma aliviar.

## 5) Checklist semanal (coloque a versão final aqui)
- (Cole do P06.)

## 6) Ações priorizadas (alto impacto)
- (Cole do P05/P04.)

## 7) Referências
- Liste as fontes usadas e as páginas/trechos relevantes.
