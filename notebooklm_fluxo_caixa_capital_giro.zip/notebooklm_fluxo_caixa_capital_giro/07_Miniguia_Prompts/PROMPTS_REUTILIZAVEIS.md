# Biblioteca de prompts reutilizáveis (para revisões)

## Prompt 1 — Lucro vs Caixa (comércio)

Explique a diferença entre lucro e caixa usando:
- 1 analogia simples
- 1 exemplo de comércio
- 3 bullets de "erros comuns"
- cite trechos/páginas das fontes


## Prompt 2 — Cálculo de ciclos e NCG

Extraia/valide as fórmulas de PME, PMR, PMP, CO, CF e NCG nas fontes.
Aplique ao case: PME=45, PMR=30, PMP=20.
Interprete o que significa e sugira 3 ações com trade-offs.
Cite trechos/páginas.


## Prompt 3 — Onde o caixa está preso?

Com base nas fontes, diga onde o caixa costuma ficar preso no comércio (estoque/recebíveis/pagáveis).
Liste 5 ações por impacto (alto→baixo), com trade-offs.
Cite trechos/páginas.


## Prompt 4 — Checklist semanal

Crie um checklist semanal de tesouraria (1 página) para comércio.
Inclua: o que checar, frequência, responsável e 6 métricas mínimas.
Cite trechos/páginas.

