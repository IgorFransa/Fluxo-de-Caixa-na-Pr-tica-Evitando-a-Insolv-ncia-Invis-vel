# Metodologia (texto pronto para o relatório)

1) **Curadoria** de 4–5 fontes abertas (PDF/texto) sobre fluxo de caixa e capital de giro.
2) **Definição** de objetivos de estudo e perguntas estratégicas.
3) **Construção** de um caso de comércio com prazos médios (PME/PMR/PMP) para testar cálculo e diagnóstico.
4) **Execução** de 6 prompts em 3 famílias (resumo, fórmulas, diagnóstico), com duas variações por família.
5) **Registro** em LOG: prompt, variação, hipótese, resposta, trechos citados, avaliação e ajustes.
6) **Síntese** final em miniguia + glossário + biblioteca de prompts reutilizáveis.

**Encoding**: documento final em UTF-8.
