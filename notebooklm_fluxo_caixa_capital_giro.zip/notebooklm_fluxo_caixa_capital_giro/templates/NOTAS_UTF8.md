# Notas de encoding (UTF-8)

- Este repositório foi gerado com arquivos em **UTF-8**.
- No VS Code, mantenha `files.encoding = utf8`.
- Se copiar/colar texto de outra fonte, confirme encoding ao salvar.
